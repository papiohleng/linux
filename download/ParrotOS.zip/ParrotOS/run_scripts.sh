#!/bin/bash

# Define the directory where the scripts are located
SCRIPT_DIR="/home/user/ParrotOS"

# Array of scripts in numerical order
SCRIPTS=("1extract_zip.sh" "2movefiles.sh" "3applythemes.sh")

# Function to make the script executable and run it
run_script() {
    script_name=$1
    script_path="$SCRIPT_DIR/$script_name"

    echo "Ensuring $script_name is executable..."
    
    # Give executable permission
    chmod +x "$script_path"

    # Check if chmod was successful
    if [ $? -ne 0 ]; then
        echo "Error: Failed to make $script_name executable. Exiting."
        exit 1
    fi

    echo "Running $script_name..."
    
    # Run the script and wait for it to complete
    bash "$script_path"

    # Check if the script ran successfully
    if [ $? -eq 0 ]; then
        echo "$script_name completed successfully."
    else
        echo "Error: $script_name failed. Exiting."
        exit 1
    fi
}

# Loop through the scripts and run them in order
for script in "${SCRIPTS[@]}"; do
    run_script "$script"
done

echo "All scripts executed successfully."

