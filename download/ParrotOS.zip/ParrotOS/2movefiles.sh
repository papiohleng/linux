#!/bin/bash

# Define the source and destination directories
SOURCE_DIR="/home/user/Downloads/ParrotOS - theme"
DEST_DIR="/home/user"

# Check if the source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: $SOURCE_DIR does not exist."
    exit 1
fi

# Move the files from source to destination
echo "Moving files from $SOURCE_DIR to $DEST_DIR..."
mv "$SOURCE_DIR"/* "$DEST_DIR"

# Check if the move was successful
if [ $? -eq 0 ]; then
    echo "Files moved successfully."
else
    echo "Error during file move."
    exit 2
fi
