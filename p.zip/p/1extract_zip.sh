# Define the source ZIP file and the destination directory
ZIP_FILE="/home/user/Downloads/ParrotOS.zip"
DEST_DIR="/home/user/Downloads/$("$ZIP_FILE" .zip)"

# Check if the ZIP file exists
if [ ! -f "$ZIP_FILE" ]; then
    echo "Error: $ZIP_FILE does not exist."
    exit 1
fi

# Check if the destination directory exists, if not, create it
if [ ! -d "$DEST_DIR" ]; then
    echo "Destination directory $DEST_DIR does not exist. Creating it..."
    mkdir -p "$DEST_DIR"
fi

# Extract the ZIP file
echo "Extracting $ZIP_FILE to $DEST_DIR..."
unzip -o "$ZIP_FILE" -d "$DEST_DIR"

# Check if the extraction was successful
if [ $? -eq 0 ]; then
    echo "Extraction complete."
else
    echo "Error during extraction."
    exit 2
fi
