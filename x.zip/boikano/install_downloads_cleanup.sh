#!/usr/bin/env bash
# =============================================================================
# Concise Parrot OS Customization Deployment Script
# Optimized for brevity, safety, and efficiency
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

HOME_DIR="${HOME:-/home/user}"
DL="${HOME_DIR}/Downloads"
ZIP="${DL}/x.zip"
EXT="${DL}/boikano"
SOFT="${HOME_DIR}/Softwares"

# Cleanup function to delete everything in Downloads when done
cleanup_downloads() {
    echo "Cleaning up Downloads directory..."
    # Remove all contents of Downloads directory
    find "${DL}" -mindepth 1 -delete 2>/dev/null || {
        # Fallback method if find fails
        rm -rf "${DL}"/* "${DL}"/.* 2>/dev/null || true
    }
    echo "Downloads directory cleaned."
}

# Setup trap to cleanup on successful exit
trap 'cleanup_downloads' EXIT

log() { echo "[$(date +'%H:%M:%S')] $*"; }

require() { [[ -e "$1" ]] || { echo "ERROR: Missing $1" >&2; exit 1; }; }

backup_mv() {
    [[ -e "$2" ]] && sudo mv "$2" "${2}.bak"
    sudo mv "$1" "$2"
}

log "=== Starting Customization Deployment ==="

# Extract
log "Extracting archive"
unzip -o "$ZIP" -d "$DL"
require "$EXT"

# Relocate user components
log "Relocating user files/directories"
for item in Appimages Softwares settings.dconf; do
    src="${EXT}/${item}"
    dst="${HOME_DIR}/${item%/}"
    require "$src"
    [[ -e "$dst" ]] && mv "$dst" "${dst}.old"
    mv "$src" "$dst"
done
require "$SOFT"

# Run internal scripts
log "Running configuration scripts"
cd "$EXT"
for s in 3applythemes.sh run_scripts.sh; do
    require "$s"
    chmod +x "$s"
    log "→ $s"
    ./"$s"
done

# Install system assets
log "Installing system-wide assets (sudo required)"
backup_mv "${SOFT}/lockscreen.jpg" /usr/share/backgrounds/lockscreen.jpg

[[ -f "${SOFT}/password-screen.jpg" ]] && {
    sudo mkdir -p /usr/share/images/desktop-base
    backup_mv "${SOFT}/password-screen.jpg" /usr/share/images/desktop-base/password-screen.jpg
}

sudo mkdir -p /usr/share/icons/hicolor/scalable/apps
backup_mv "${SOFT}/icon.svg"        /usr/share/icons/hicolor/scalable/apps/custom-icon.svg
backup_mv "${SOFT}/parrot-logo.svg" /usr/share/icons/hicolor/scalable/apps/parrot-logo.svg

sudo gtk-update-icon-cache /usr/share/icons/hicolor 2>/dev/null || true

log "=== Deployment Complete ==="
cat <<EOF
Customizations applied:
• Login window, lock screen, screensaver, themes, icons
• Apps in ~/Appimages & ~/Softwares

Tip: Double-click username on login screen to change password.
Existing system files backed up as .bak

Note: Downloads directory has been cleaned automatically.
EOF

# Explicit cleanup (in case trap doesn't fire)
cleanup_downloads
