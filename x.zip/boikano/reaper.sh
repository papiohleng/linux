#!/bin/bash
set -euo pipefail

DOWNLOADS="/home/user/Downloads"
REAPER_DIR="/home/user/Music/reaper"
BINARY="$REAPER_DIR/REAPER/reaper"
FFMPEG_LIB="$REAPER_DIR/REAPER/ffmpeg 4.2/lib"

mkdir -p "$REAPER_DIR"

# Extract reaper*.tar.xz directly into final dir (strip top-level folder)
for tar in "$DOWNLOADS"/reaper*.tar.xz; do
    [ -f "$tar" ] && tar -xf "$tar" --strip-components=1 -C "$REAPER_DIR" && rm "$tar"
done

# Prevent any nested reaper/reaper
[ -d "$REAPER_DIR/reaper" ] && rm -rf "$REAPER_DIR/reaper"

# Move reaper.txt
[ -f "$DOWNLOADS/reaper/reaper.txt" ] && mv "$DOWNLOADS/reaper/reaper.txt" "$REAPER_DIR/"

# Extract r.zip
[ -f "$DOWNLOADS/r.zip" ] && unzip -o "$DOWNLOADS/r.zip" -d "$REAPER_DIR" && rm "$DOWNLOADS/r.zip"

# Move ffmpeg folder if present
[ -d "$DOWNLOADS/reaper/REAPER/ffmpeg 4.2" ] && mv "$DOWNLOADS/reaper/REAPER/ffmpeg 4.2" "$REAPER_DIR/REAPER/"

# Launch REAPER
[ -x "$BINARY" ] || { echo "REAPER binary not found!"; exit 1; }
cd "$REAPER_DIR"
export LD_LIBRARY_PATH="$FFMPEG_LIB:${LD_LIBRARY_PATH:-}"
exec "$BINARY" "$@"
