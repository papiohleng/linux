#!/bin/bash

# Define constants for paths and theme files
THEME_PATH="/home/user/Appimages/themes"
THEMES=("BeautySolar.tar.gz" "Fuchsia.tar.xz" "Fuchsia-Red.tar.xz" "Shades-of-purple.tar.xz" "Shades-of-purple-standard-buttons.tar.xz")
TEMP_DIR=$(mktemp -d)  # Temporary directory for theme extraction

# Function to print messages in a consistent format
log_message() {
    echo "[INFO] $1"
}

# Function to print error messages
log_error() {
    echo "[ERROR] $1" >&2
}

# Check if the themes directory exists
if [ ! -d "$THEME_PATH" ]; then
    log_error "Themes directory $THEME_PATH does not exist."
    exit 1
fi
log_message "Using theme directory: $THEME_PATH"

# Function to extract and install a theme
install_theme() {
    local file="$1"
    local filename=$(basename "$file")
    log_message "Processing $filename..."

    # Extract theme based on file extension
    case "$file" in
        *.tar.gz) tar -xzf "$file" -C "$TEMP_DIR" ;;
        *.tar.xz) tar -xJf "$file" -C "$TEMP_DIR" ;;
        *) log_error "Unsupported file format: $filename"; return 1 ;;
    esac

    if [ $? -ne 0 ]; then
        log_error "Failed to extract $filename."
        return 1
    fi

    # Find the extracted theme directory (limit to one directory)
    extracted_dir=$(find "$TEMP_DIR" -maxdepth 1 -type d ! -path "$TEMP_DIR" | head -n 1)
    if [ -z "$extracted_dir" ]; then
        log_error "No theme directory found in $filename."
        return 1
    fi

    theme_name=$(basename "$extracted_dir")
    log_message "Found theme: $theme_name"

    # Determine the destination based on the theme
    case "$theme_name" in
        "BeautySolar") dest_dir="$HOME/.icons" ;;
        "Fuchsia" | "Fuchsia-Red") dest_dir="$HOME/.icons" ;;
        *) dest_dir="$HOME/.themes" ;;
    esac

    # Create destination directory if it doesn't exist
    mkdir -p "$dest_dir" || { log_error "Failed to create $dest_dir"; return 1; }

    # Remove any existing theme directory if necessary
    if [ -d "$dest_dir/$theme_name" ]; then
        rm -rf "$dest_dir/$theme_name" || { log_error "Failed to remove existing theme $theme_name"; return 1; }
        log_message "Removed existing theme $theme_name"
    fi

    # Move extracted theme to the destination directory
    mv "$extracted_dir" "$dest_dir/" || { log_error "Failed to install theme $theme_name"; return 1; }
    log_message "Installed theme $theme_name to $dest_dir"

    # Apply the theme if it matches specific criteria
    case "$theme_name" in
        "Shades-of-purple") gsettings set org.mate.interface gtk-theme "$theme_name" ;;
        "BeautySolar") gsettings set org.mate.interface icon-theme "$theme_name" ;;
        "Fuchsia") gsettings set org.mate.peripherals-mouse cursor-theme "$theme_name" ;;
    esac

    # Check if the theme was successfully applied
    if [ $? -eq 0 ]; then
        log_message "Successfully applied $theme_name theme."
    else
        log_error "Failed to apply $theme_name theme."
    fi
}

# Iterate over all theme files and install them
for theme in "${THEMES[@]}"; do
    theme_file="$THEME_PATH/$theme"
    if [ -f "$theme_file" ]; then
        # Clear TEMP_DIR contents before processing each theme
        rm -rf "$TEMP_DIR/*" || { log_error "Failed to clear temporary directory"; exit 1; }
        install_theme "$theme_file"
    else
        log_error "⚠️ Theme file $theme_file not found!"
    fi
done

# Apply the default window border theme
gsettings set org.mate.Marco.general theme 'Air' || log_error "Failed to apply window border theme 'Air'"

# Clean up temporary directory
rm -rf "$TEMP_DIR"
log_message "Cleaned up temporary directory"

# Final message
log_message "Theme installation and application complete."

# Set file permissions for application binaries
sudo find /home/user/Softwares -type f \( -iname "*.AppImage" -o -iname "*.deb" -o -iname "*.run" \) -exec chmod 777 {} +

# Load settings from dconf
dconf load / < /home/user/settings.dconf || log_error "Failed to load settings from dconf"

log_message "Configuration complete."

